
import { useEffect, useState } from 'react';
import { validateToken } from '../../../services/authService';

export default function AdminGlobalDashboard() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) {
      validateToken(token).then((data) => {
        if (data && data.valid) {
          setUser(data);
        }
      });
    }
  }, []);

  if (!user) return <p className="text-center mt-10">Cargando...</p>;

  return (
    <div className="p-4">
      <h1 className="text-xl font-bold mb-2">Bienvenido, {user.nickname}</h1>
      <p className="text-gray-600">Rol: {user.role}</p>
      <p className="text-gray-600">ID: {user.id}</p>
    </div>
  );
}
