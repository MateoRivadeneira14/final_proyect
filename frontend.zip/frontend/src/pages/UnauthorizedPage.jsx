export default function UnauthorizedPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100">
      <div className="bg-white p-8 rounded shadow text-center">
        <h1 className="text-2xl font-bold mb-4 text-red-600">Acceso no autorizado</h1>
        <p className="text-gray-700">No tienes permiso para ver esta página.</p>
      </div>
    </div>
  );
}
