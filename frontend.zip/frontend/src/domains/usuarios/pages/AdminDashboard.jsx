import Navbar from '../../../components/Navbar';

export default function AdminDashboard() {
  return (
    <>
      <Navbar />
      <div className="p-6">
        <h1 className="text-2xl font-bold mb-4">Panel del Administrador</h1>
        <p>Desde aquí puedes gestionar usuarios, roles y accesos.</p>
      </div>
    </>
  );
}
