import Navbar from '../../../components/Navbar';

export default function EstudianteDashboard() {
  return (
    <>
      <Navbar />
      <div className="p-6">
        <h1 className="text-2xl font-bold mb-4">Bienvenido, Estudiante</h1>
        <p>Aquí puedes ver tu historial, hacer solicitudes y consultar recursos.</p>
      </div>
    </>
  );
}
